import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const documents = pgTable("documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  url: text("url").notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  wordCount: text("word_count"),
  extractedAt: timestamp("extracted_at").defaultNow(),
});

export const conversations = pgTable("conversations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  documentId: varchar("document_id").notNull(),
  question: text("question").notNull(),
  answer: text("answer").notNull(),
  responseTime: text("response_time"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  extractedAt: true,
});

export const insertConversationSchema = createInsertSchema(conversations).omit({
  id: true,
  createdAt: true,
});

export type InsertDocument = z.infer<typeof insertDocumentSchema>;
export type Document = typeof documents.$inferSelect;
export type InsertConversation = z.infer<typeof insertConversationSchema>;
export type Conversation = typeof conversations.$inferSelect;

// API request/response schemas
export const processDocumentSchema = z.object({
  url: z.string().url().refine(
    (url) => url.includes('docs.google.com/document/'),
    { message: "Must be a valid Google Docs URL" }
  ),
});

export const askQuestionSchema = z.object({
  documentId: z.string(),
  question: z.string().min(1, "Question cannot be empty"),
});

export type ProcessDocumentRequest = z.infer<typeof processDocumentSchema>;
export type AskQuestionRequest = z.infer<typeof askQuestionSchema>;