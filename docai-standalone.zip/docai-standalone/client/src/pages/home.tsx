import Header from "@/components/header";
import HeroSection from "@/components/hero-section";
import DocumentUpload from "@/components/document-upload";
import QuestionAnswerSection from "@/components/question-answer-section";
import FeaturesSection from "@/components/features-section";
import Footer from "@/components/footer";
import { useState } from "react";
import { Document } from "@shared/schema";

export default function Home() {
  const [currentDocument, setCurrentDocument] = useState<Document | null>(null);

  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      <Header />
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <HeroSection />
        <DocumentUpload onDocumentProcessed={setCurrentDocument} />
        <QuestionAnswerSection document={currentDocument} />
        <FeaturesSection />
      </main>
      <Footer />
    </div>
  );
}