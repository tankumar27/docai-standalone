import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { processDocumentSchema, type ProcessDocumentRequest, type Document } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface DocumentUploadProps {
  onDocumentProcessed: (document: Document) => void;
}

export default function DocumentUpload({ onDocumentProcessed }: DocumentUploadProps) {
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);

  const form = useForm<ProcessDocumentRequest>({
    resolver: zodResolver(processDocumentSchema),
    defaultValues: {
      url: "",
    },
  });

  const processDocumentMutation = useMutation<Document, Error, ProcessDocumentRequest>({
    mutationFn: async (data: ProcessDocumentRequest): Promise<Document> => {
      const response = await apiRequest("POST", "/api/documents/process", data);
      return response.json();
    },
    onSuccess: (document: Document) => {
      toast({
        title: "Document processed successfully!",
        description: `"${document.title}" is ready for questions.`,
      });
      onDocumentProcessed(document);
      form.reset();
      setIsProcessing(false);
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to process document",
        description: error.message,
      });
      setIsProcessing(false);
    },
  });

  const onSubmit = (data: ProcessDocumentRequest) => {
    setIsProcessing(true);
    processDocumentMutation.mutate(data);
  };

  return (
    <div className="max-w-2xl mx-auto mb-8">
      <div className="bg-card rounded-lg border border-border p-6">
        <div className="mb-6">
          <h3 className="text-lg font-semibold mb-2">Upload Document</h3>
          <p className="text-sm text-muted-foreground">
            Paste a Google Docs URL to get started. Make sure the document is shared publicly or with "Anyone with the link can view".
          </p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="url"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Google Docs URL</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="https://docs.google.com/document/d/..."
                      {...field}
                      data-testid="input-document-url"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button 
              type="submit" 
              disabled={isProcessing}
              className="w-full"
              data-testid="button-process-document"
            >
              {isProcessing ? (
                <>
                  <i className="fas fa-spinner fa-spin mr-2" />
                  Processing Document...
                </>
              ) : (
                <>
                  <i className="fas fa-upload mr-2" />
                  Process Document
                </>
              )}
            </Button>
          </form>
        </Form>

        <div className="mt-4 p-4 bg-muted/50 rounded-lg">
          <h4 className="text-sm font-medium mb-2 flex items-center">
            <i className="fas fa-info-circle mr-2 text-primary" />
            How to share your Google Doc:
          </h4>
          <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
            <li>Open your Google Doc</li>
            <li>Click "Share" in the top right</li>
            <li>Change access to "Anyone with the link can view"</li>
            <li>Copy the document URL and paste it above</li>
          </ol>
        </div>
      </div>
    </div>
  );
}