export default function HeroSection() {
  return (
    <div className="text-center mb-12">
      <h2 className="text-3xl sm:text-4xl font-bold mb-4 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
        Extract Knowledge from Google Docs
      </h2>
      <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
        Simply paste a Google Doc URL and ask questions about the content. Our AI will analyze the document and provide intelligent answers.
      </p>
    </div>
  );
}