export default function FeaturesSection() {
  return (
    <div className="max-w-4xl mx-auto mt-16">
      <div className="text-center mb-12">
        <h3 className="text-2xl font-bold mb-4">Powerful Document Analysis</h3>
        <p className="text-muted-foreground">
          Leverage AI to extract insights and answer questions from your Google Docs
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-card rounded-lg border border-border p-6 text-center">
          <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-bolt text-primary text-xl" />
          </div>
          <h4 className="font-semibold mb-2">Fast Processing</h4>
          <p className="text-sm text-muted-foreground">
            Quick document analysis and instant AI-powered responses to your questions
          </p>
        </div>
        
        <div className="bg-card rounded-lg border border-border p-6 text-center">
          <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-shield-alt text-accent text-xl" />
          </div>
          <h4 className="font-semibold mb-2">Secure & Private</h4>
          <p className="text-sm text-muted-foreground">
            Your documents are processed securely with privacy protection built-in
          </p>
        </div>
        
        <div className="bg-card rounded-lg border border-border p-6 text-center">
          <div className="w-12 h-12 bg-secondary rounded-lg flex items-center justify-center mx-auto mb-4">
            <i className="fas fa-brain text-muted-foreground text-xl" />
          </div>
          <h4 className="font-semibold mb-2">Smart Analysis</h4>
          <p className="text-sm text-muted-foreground">
            Advanced AI understands context and provides accurate, relevant answers
          </p>
        </div>
      </div>
    </div>
  );
}