export default function Header() {
  return (
    <header className="border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <i className="fas fa-brain text-primary-foreground text-sm" />
              </div>
              <h1 className="text-xl font-bold text-foreground">DocAI</h1>
            </div>
            <div className="hidden sm:block text-muted-foreground text-sm">
              AI-Powered Document Analysis
            </div>
          </div>
          <nav className="flex items-center space-x-4">
            <button 
              className="text-muted-foreground hover:text-foreground transition-colors"
              data-testid="button-help"
            >
              <i className="fas fa-question-circle" />
              <span className="sr-only">Help</span>
            </button>
            <button 
              className="text-muted-foreground hover:text-foreground transition-colors"
              data-testid="button-settings"
            >
              <i className="fas fa-cog" />
              <span className="sr-only">Settings</span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
}