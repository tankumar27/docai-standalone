import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { askQuestionSchema, type AskQuestionRequest, type Document, type Conversation } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";

interface QuestionAnswerProps {
  document: Document | null;
}

export default function QuestionAnswerSection({ document }: QuestionAnswerProps) {
  const { toast } = useToast();
  const [isAsking, setIsAsking] = useState(false);
  const [quickQuestions, setQuickQuestions] = useState<string[]>([]);

  const form = useForm<AskQuestionRequest>({
    resolver: zodResolver(askQuestionSchema),
    defaultValues: {
      documentId: "",
      question: "",
    },
  });

  // Update form when document changes
  useEffect(() => {
    if (document) {
      form.setValue("documentId", document.id);
    }
  }, [document, form]);

  // Fetch conversations for the document
  const { data: conversations = [], isLoading: loadingConversations } = useQuery<Conversation[]>({
    queryKey: ["/api/documents", document?.id, "conversations"],
    enabled: !!document,
  });

  // Generate quick questions
  const generateQuickQuestionsMutation = useMutation<{ questions: string[] }, Error, string>({
    mutationFn: async (documentId: string): Promise<{ questions: string[] }> => {
      const response = await apiRequest("POST", `/api/documents/${documentId}/quick-questions`);
      return response.json();
    },
    onSuccess: (data: { questions: string[] }) => {
      setQuickQuestions(data.questions);
    },
  });

  // Ask question mutation
  const askQuestionMutation = useMutation<Conversation, Error, AskQuestionRequest>({
    mutationFn: async (data: AskQuestionRequest): Promise<Conversation> => {
      const response = await apiRequest("POST", "/api/conversations", data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Question answered!",
        description: "Your question has been processed successfully.",
      });
      queryClient.invalidateQueries({
        queryKey: ["/api/documents", document?.id, "conversations"]
      });
      form.setValue("question", "");
      setIsAsking(false);
    },
    onError: (error: Error) => {
      toast({
        variant: "destructive",
        title: "Failed to process question",
        description: error.message,
      });
      setIsAsking(false);
    },
  });

  // Generate quick questions when document is loaded
  useEffect(() => {
    if (document && quickQuestions.length === 0) {
      generateQuickQuestionsMutation.mutate(document.id);
    }
  }, [document]);

  const onSubmit = (data: AskQuestionRequest) => {
    setIsAsking(true);
    askQuestionMutation.mutate(data);
  };

  const handleQuickQuestion = (question: string) => {
    if (document) {
      setIsAsking(true);
      askQuestionMutation.mutate({
        documentId: document.id,
        question,
      });
    }
  };

  if (!document) {
    return (
      <div className="max-w-4xl mx-auto mb-8">
        <div className="bg-muted/30 rounded-lg border-2 border-dashed border-border p-12 text-center">
          <i className="fas fa-file-upload text-4xl text-muted-foreground mb-4" />
          <h3 className="text-lg font-medium text-muted-foreground mb-2">
            No document loaded
          </h3>
          <p className="text-sm text-muted-foreground">
            Upload a Google Doc above to start asking questions about its content.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto mb-8">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Question Input */}
        <div className="bg-card rounded-lg border border-border p-6">
          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-2">Ask a Question</h3>
            <p className="text-sm text-muted-foreground">
              Ask anything about "{document.title}" ({document.wordCount} words)
            </p>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="question"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Your Question</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="What is the main topic of this document?"
                        className="min-h-[100px]"
                        {...field}
                        data-testid="textarea-question"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                disabled={isAsking}
                className="w-full"
                data-testid="button-ask-question"
              >
                {isAsking ? (
                  <>
                    <i className="fas fa-spinner fa-spin mr-2" />
                    Asking...
                  </>
                ) : (
                  <>
                    <i className="fas fa-question-circle mr-2" />
                    Ask Question
                  </>
                )}
              </Button>
            </form>
          </Form>

          {/* Quick Questions */}
          {quickQuestions.length > 0 && (
            <div className="mt-6">
              <h4 className="text-sm font-medium mb-3">Quick Questions:</h4>
              <div className="space-y-2">
                {quickQuestions.map((question, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    size="sm"
                    className="w-full text-left justify-start h-auto py-2 px-3"
                    onClick={() => handleQuickQuestion(question)}
                    disabled={isAsking}
                    data-testid={`button-quick-question-${index}`}
                  >
                    <i className="fas fa-lightbulb mr-2 text-accent" />
                    <span className="text-sm">{question}</span>
                  </Button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Conversation History */}
        <div className="bg-card rounded-lg border border-border p-6">
          <div className="mb-4">
            <h3 className="text-lg font-semibold">Conversation History</h3>
          </div>

          <div className="space-y-4 max-h-96 overflow-y-auto">
            {loadingConversations ? (
              <div className="flex items-center justify-center py-8">
                <i className="fas fa-spinner fa-spin text-muted-foreground" />
                <span className="ml-2 text-sm text-muted-foreground">Loading conversations...</span>
              </div>
            ) : conversations.length === 0 ? (
              <div className="text-center py-8">
                <i className="fas fa-comments text-2xl text-muted-foreground mb-2" />
                <p className="text-sm text-muted-foreground">
                  No questions asked yet. Start by asking a question about the document.
                </p>
              </div>
            ) : (
              conversations.map((conversation) => (
                <div key={conversation.id} className="space-y-3" data-testid={`conversation-${conversation.id}`}>
                  <div className="bg-primary/5 rounded-lg p-3">
                    <div className="flex items-start space-x-2">
                      <i className="fas fa-user text-primary mt-1" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-primary">You asked:</p>
                        <p className="text-sm text-foreground mt-1">{conversation.question}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-accent/5 rounded-lg p-3">
                    <div className="flex items-start space-x-2">
                      <i className="fas fa-robot text-accent mt-1" />
                      <div className="flex-1">
                        <p className="text-sm font-medium text-accent">AI answered:</p>
                        <div className="text-sm text-foreground mt-1 prose prose-sm max-w-none">
                          {conversation.answer.split('\n').map((line, index) => (
                            <p key={index} className="mb-2 last:mb-0">{line}</p>
                          ))}
                        </div>
                        <p className="text-xs text-muted-foreground mt-2">
                          Response time: {conversation.responseTime}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}