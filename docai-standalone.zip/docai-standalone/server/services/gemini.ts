import { GoogleGenAI } from "@google/genai";

export interface QuestionResponse {
  answer: string;
  responseTime: number;
}

export class GeminiService {
  private ai: GoogleGenAI;

  constructor() {
    // Use GOOGLE_API_KEY (from Google AI Studio) or fallback to GEMINI_API_KEY
    const apiKey = process.env.GOOGLE_API_KEY || process.env.GEMINI_API_KEY || "";
    if (process.env.GOOGLE_API_KEY && process.env.GEMINI_API_KEY) {
      console.log('Both GOOGLE_API_KEY and GEMINI_API_KEY are set. Using GOOGLE_API_KEY.');
    }
    this.ai = new GoogleGenAI({ 
      apiKey: apiKey
    });
  }

  async answerQuestion(documentContent: string, documentTitle: string, question: string): Promise<QuestionResponse> {
    const startTime = Date.now();

    try {
      const prompt = `You are an intelligent document analysis assistant. You have been provided with the content of a document titled "${documentTitle}". 

Document Content:
${documentContent}

Please answer the following question based solely on the content provided above. If the answer cannot be found in the document, please state that clearly. Provide a comprehensive but concise answer.

Question: ${question}

Please format your response in a clear, well-structured manner using markdown formatting where appropriate.`;

      const response = await this.ai.models.generateContent({
        model: "gemini-1.5-flash",
        contents: prompt,
      });

      const answer = response.text || "I apologize, but I was unable to generate a response to your question.";
      const responseTime = Date.now() - startTime;

      return {
        answer,
        responseTime,
      };
    } catch (error: any) {
      throw new Error(`Failed to generate AI response: ${error.message}`);
    }
  }

  async generateQuickQuestions(documentContent: string, documentTitle: string): Promise<string[]> {
    try {
      const prompt = `Based on the following document titled "${documentTitle}", generate 3-5 relevant questions that a user might want to ask about the content. Make the questions specific and useful.

Document Content:
${documentContent.substring(0, 2000)}...

Return only the questions as a JSON array of strings.`;

      const response = await this.ai.models.generateContent({
        model: "gemini-1.5-flash",
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              questions: {
                type: "array",
                items: { type: "string" }
              }
            },
            required: ["questions"]
          }
        },
        contents: prompt,
      });

      const result = JSON.parse(response.text || "{}");
      return result.questions || [
        "What is the main topic?",
        "Summarize key points", 
        "What are the action items?"
      ];
    } catch (error) {
      // Return default questions if AI generation fails
      return [
        "What is the main topic?",
        "Summarize key points", 
        "What are the action items?"
      ];
    }
  }
}

export const geminiService = new GeminiService();