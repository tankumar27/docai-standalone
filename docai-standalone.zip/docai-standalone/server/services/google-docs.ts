export interface DocumentContent {
  title: string;
  content: string;
  wordCount: number;
}

export class GoogleDocsService {
  constructor() {
    // No authentication needed for public documents
  }

  extractDocumentId(url: string): string {
    const match = url.match(/\/document\/d\/([a-zA-Z0-9-_]+)/);
    if (!match) {
      throw new Error('Invalid Google Docs URL format');
    }
    return match[1];
  }

  async extractContent(url: string): Promise<DocumentContent> {
    try {
      const documentId = this.extractDocumentId(url);
      
      // Convert Google Docs URL to export format (plain text)
      const exportUrl = `https://docs.google.com/document/d/${documentId}/export?format=txt`;
      
      const response = await fetch(exportUrl);
      
      if (!response.ok) {
        if (response.status === 404) {
          throw new Error('Document not found. Please check the URL and ensure the document exists.');
        } else if (response.status === 403) {
          throw new Error('Access denied. Please make sure the document is shared publicly. Go to your Google Doc → Share → Change to "Anyone with the link" can view.');
        } else {
          throw new Error(`Failed to access document. Status: ${response.status}`);
        }
      }
      
      const content = await response.text();
      
      if (!content || content.trim().length === 0) {
        throw new Error('Document appears to be empty or inaccessible. Please ensure the document is shared publicly.');
      }

      // Extract title from URL or use default
      const title = `Document ${documentId.substring(0, 8)}`;
      const wordCount = content.split(/\s+/).filter(word => word.length > 0).length;

      return {
        title,
        content: content.trim(),
        wordCount,
      };
    } catch (error: any) {
      throw new Error(error.message || 'Failed to extract document content');
    }
  }
}

export const googleDocsService = new GoogleDocsService();