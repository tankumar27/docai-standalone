import { type Document, type InsertDocument, type Conversation, type InsertConversation } from "../shared/schema.js";
import { randomUUID } from "crypto";

export interface IStorage {
  // Document operations
  createDocument(document: InsertDocument): Promise<Document>;
  getDocument(id: string): Promise<Document | undefined>;
  getDocumentByUrl(url: string): Promise<Document | undefined>;
  getAllDocuments(): Promise<Document[]>;

  // Conversation operations
  createConversation(conversation: InsertConversation): Promise<Conversation>;
  getConversationsByDocumentId(documentId: string): Promise<Conversation[]>;
  getConversation(id: string): Promise<Conversation | undefined>;
}

export class MemStorage implements IStorage {
  private documents: Map<string, Document>;
  private conversations: Map<string, Conversation>;

  constructor() {
    this.documents = new Map();
    this.conversations = new Map();
  }

  async createDocument(insertDocument: InsertDocument): Promise<Document> {
    const id = randomUUID();
    const document: Document = {
      ...insertDocument,
      id,
      extractedAt: new Date(),
    };
    this.documents.set(id, document);
    return document;
  }

  async getDocument(id: string): Promise<Document | undefined> {
    return this.documents.get(id);
  }

  async getDocumentByUrl(url: string): Promise<Document | undefined> {
    return Array.from(this.documents.values()).find(doc => doc.url === url);
  }

  async getAllDocuments(): Promise<Document[]> {
    return Array.from(this.documents.values());
  }

  async createConversation(insertConversation: InsertConversation): Promise<Conversation> {
    const id = randomUUID();
    const conversation: Conversation = {
      ...insertConversation,
      id,
      createdAt: new Date(),
    };
    this.conversations.set(id, conversation);
    return conversation;
  }

  async getConversationsByDocumentId(documentId: string): Promise<Conversation[]> {
    return Array.from(this.conversations.values())
      .filter(conv => conv.documentId === documentId)
      .sort((a, b) => a.createdAt!.getTime() - b.createdAt!.getTime());
  }

  async getConversation(id: string): Promise<Conversation | undefined> {
    return this.conversations.get(id);
  }
}

export const storage = new MemStorage();