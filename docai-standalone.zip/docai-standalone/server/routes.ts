import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage.js";
import { googleDocsService } from "./services/google-docs.js";
import { geminiService } from "./services/gemini.js";
import { processDocumentSchema, askQuestionSchema } from "../shared/schema.js";

export async function registerRoutes(app: Express): Promise<Server> {
  // Process Google Doc URL and extract content
  app.post("/api/documents/process", async (req, res) => {
    try {
      const { url } = processDocumentSchema.parse(req.body);

      // Check if document already exists
      const existingDocument = await storage.getDocumentByUrl(url);
      if (existingDocument) {
        return res.json(existingDocument);
      }

      // Extract content from Google Docs
      const documentContent = await googleDocsService.extractContent(url);

      // Store document in memory
      const document = await storage.createDocument({
        url,
        title: documentContent.title,
        content: documentContent.content,
        wordCount: documentContent.wordCount.toString(),
      });

      res.json(document);
    } catch (error: any) {
      console.error("Document processing error:", error);
      res.status(400).json({ 
        message: error.message || "Failed to process document"
      });
    }
  });

  // Ask question about a document
  app.post("/api/conversations", async (req, res) => {
    try {
      const { documentId, question } = askQuestionSchema.parse(req.body);

      // Get document
      const document = await storage.getDocument(documentId);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }

      // Get AI answer
      const aiResponse = await geminiService.answerQuestion(
        document.content,
        document.title,
        question
      );

      // Store conversation
      const conversation = await storage.createConversation({
        documentId,
        question,
        answer: aiResponse.answer,
        responseTime: `${aiResponse.responseTime}ms`,
      });

      res.json(conversation);
    } catch (error: any) {
      console.error("Question answering error:", error);
      res.status(400).json({ 
        message: error.message || "Failed to process question"
      });
    }
  });

  // Get conversations for a document
  app.get("/api/documents/:id/conversations", async (req, res) => {
    try {
      const { id } = req.params;
      const conversations = await storage.getConversationsByDocumentId(id);
      res.json(conversations);
    } catch (error: any) {
      console.error("Get conversations error:", error);
      res.status(500).json({ 
        message: "Failed to retrieve conversations"
      });
    }
  });

  // Generate quick questions for a document
  app.post("/api/documents/:id/quick-questions", async (req, res) => {
    try {
      const { id } = req.params;
      
      const document = await storage.getDocument(id);
      if (!document) {
        return res.status(404).json({ message: "Document not found" });
      }

      const questions = await geminiService.generateQuickQuestions(
        document.content,
        document.title
      );

      res.json({ questions });
    } catch (error: any) {
      console.error("Quick questions error:", error);
      res.status(500).json({ 
        message: "Failed to generate quick questions"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}